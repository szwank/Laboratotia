czyszczenie = fopen('dane.txt','w');
fclose(czyszczenie);


options = optimoptions('fminunc','Display','iter','DiffMinChange',0.1,'OutputFcn',@outfunFminsearch)

fminunc(@optymalizacja,[101 10 10],options)
%% 
clc;

h=1;
gamma=0.8185;
k02=10;
Co2_sat=0.3;
alfa=3.34;